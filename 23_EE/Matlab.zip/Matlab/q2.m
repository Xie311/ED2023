% 生成原始信号
n_original = 0:26;
x = zeros(size(n_original));
x(n_original <= 13) = n_original(n_original <= 13) + 1;
x(n_original >= 14 & n_original <= 26) = 27 - n_original(n_original >= 14 & n_original <= 26);

% 计算X(e^{jΩ})幅度谱（补零到1024点）
N_dtft = 1024;
X_dtft = fft(x, N_dtft);
mag_X_dtft = abs(X_dtft);
omega_dtft = linspace(0, 2*pi, N_dtft); 

% 频域采样32点和16点
N32 = 32;
X32 = fft(x, N32);
mag_X32 = abs(X32);
omega32 = linspace(0, 2*pi, N32);

N16 = 16;
X16 = fft(x, N16);
mag_X16 = abs(X16);
omega16 = linspace(0, 2*pi, N16);

% IDFT恢复信号
x32 = ifft(X32);
x16 = ifft(X16);

% 绘制图像
figure('Position', [100, 100, 1200, 900]); % 增大图像尺寸

% 原始信号 (subplot 1)
subplot(3,2,1);
stem(n_original, x, 'filled', 'MarkerSize', 5, 'LineWidth', 1);
title('原始信号 x(n)', 'FontSize', 10);
xlabel('n', 'FontSize', 9); ylabel('幅值', 'FontSize', 9);
xlim([-1 27]); ylim([0 15]); % 扩展横纵轴范围
grid on;

% X(e^{jΩ})幅度谱 (subplot 2)
subplot(3,2,2);
plot(omega_dtft, mag_X_dtft, 'LineWidth', 1);
title('连续幅度谱 X(e^{j\Omega})', 'FontSize', 10);
xlabel('\Omega (rad)', 'FontSize', 9); ylabel('|X(e^{j\Omega})|', 'FontSize', 9);
xlim([0 2*pi]); ylim([0 200]); % 限制纵轴以突出主瓣
grid on;

% X32(k)幅度谱 (subplot 3)
subplot(3,2,3);
stem(omega32, mag_X32, 'filled', 'MarkerSize', 5, 'LineWidth', 1);
title('32点采样幅度谱 X_{32}(k)', 'FontSize', 10);
xlabel('\Omega (rad)', 'FontSize', 9); ylabel('|X_{32}(k)|', 'FontSize', 9);
xlim([0 2*pi]); ylim([0 200]); % 与连续谱对齐
grid on;

% x32(n)波形 (subplot 4)
subplot(3,2,4);
stem(0:N32-1, real(x32), 'filled', 'MarkerSize', 5, 'LineWidth', 1);
title('32点IDFT恢复信号 x_{32}(n)', 'FontSize', 10);
xlabel('n', 'FontSize', 9); ylabel('幅值', 'FontSize', 9);
xlim([-1 32]); ylim([-1 15]); % 扩展横纵轴范围
grid on;

% X16(k)幅度谱 (subplot 5)
subplot(3,2,5);
stem(omega16, mag_X16, 'filled', 'MarkerSize', 5, 'LineWidth', 1);
title('16点采样幅度谱 X_{16}(k)', 'FontSize', 10);
xlabel('\Omega (rad)', 'FontSize', 9); ylabel('|X_{16}(k)|', 'FontSize', 9);
xlim([0 2*pi]); ylim([0 200]); % 与连续谱对齐
grid on;

% x16(n)波形 (subplot 6)
subplot(3,2,6);
stem(0:N16-1, real(x16), 'filled', 'MarkerSize', 5, 'LineWidth', 1);
title('16点IDFT恢复信号 x_{16}(n)', 'FontSize', 10);
xlabel('n', 'FontSize', 9); ylabel('幅值', 'FontSize', 9);
xlim([-1 16]); ylim([-1 15]); % 扩展横纵轴范围
grid on;

% 调整子图间距
set(gcf, 'Color', 'w');