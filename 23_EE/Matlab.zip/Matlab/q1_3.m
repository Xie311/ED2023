% 参数设置
A = 444.128;
alpha = 50 * sqrt(2) * pi;
omega1 = 50 * sqrt(2) * pi; % rad/s
T_p = 0.064; % 观察时间（秒）
fs_list = [1000, 300, 200]; % 采样频率列表

figure('Position', [100, 100, 1000, 1200]); % 设置图像尺寸

for i = 1:length(fs_list)
    fs = fs_list(i);
    Ts = 1 / fs; % 采样周期
    N = round(T_p * fs); % 采样点数
    n = 0:N-1; % 采样索引
    t = n * Ts; % 采样时间点
    
    % 生成时域信号
    x = A * exp(-alpha * t) .* sin(omega1 * t);
    
    % 绘制时域图（左列）
    subplot(3, 2, 2*i-1);
    stem(t, x, 'MarkerSize', 2, 'LineWidth', 0.5);
    xlabel('Time (s)');
    ylabel('Amplitude');
    title(sprintf('f_s = %d Hz, Time Domain', fs));
    
    % 计算FFT并获取幅度谱
    X = fft(x);
    mag = abs(X);
    
    % 数字频率轴（主值区间 0~N-1）
    digital_freq = 0:N-1;

    
 % 补零操作
    N_fft = 8 * N; % 补零到8倍长度
    X_smooth = fft(x, N_fft);
    mag_smooth = abs(X_smooth);
    
    % 映射到主值区间 0~N-1
    digital_freq_smooth = linspace(0, N-1, N_fft);
    
    % 绘制平滑曲线（右列）
    subplot(3, 2, 2*i);
    plot(digital_freq_smooth, mag_smooth, 'LineWidth', 1);
    xlabel('Digital Frequency Index (n)');
    ylabel('Magnitude');
    title(sprintf('f_s = %d Hz, Smoothed (n=0~%d)', fs, N-1));
    xlim([0, N-1]);
    grid on;

end

% 调整子图间距
set(gcf, 'Color', 'w');